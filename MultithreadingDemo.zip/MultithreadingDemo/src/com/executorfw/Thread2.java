package com.executorfw;

public class Thread2 implements Runnable {

	int num;

	public Thread2(int num) {
		super();
		this.num = num;
	}

	@Override
	public void run() {
		System.out.println("square= "+num*num +" calculated by "+Thread.currentThread().getName());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(" task completed by "+Thread.currentThread().getName());
	}

}
