package com.executorfw;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestApp1 {
	
	public static void main(String[] args) {
		
		Thread1 arrayT1[] = {new Thread1("task1"), new Thread1("task2"), new Thread1("task3"), new Thread1("task4")};
		
		ExecutorService servicePool = Executors.newFixedThreadPool(1);
		
		for(Thread1 task:arrayT1) {
			servicePool.submit(task);
		}
		servicePool.shutdown();
		
	}

}
