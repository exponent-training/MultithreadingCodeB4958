package com.executorfw;

public class Thread1 implements Runnable {

	String taskname;

	public Thread1(String taskname) {
		super();
		this.taskname = taskname;
	}

	@Override
	public void run(){
		System.out.println(taskname+" started by "+Thread.currentThread().getName());
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(taskname+" completed by "+Thread.currentThread().getName());
	}

}
