package com.executorcallable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class TestCallable {
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		List<ThreadCallable> list = new ArrayList<ThreadCallable>();
		
		list = Arrays.asList(new ThreadCallable(4),new ThreadCallable(5),new ThreadCallable(6),new ThreadCallable(3));
		
		ExecutorService service = Executors.newFixedThreadPool(2);
		for (ThreadCallable threadCallable : list) {
			Future factorial = service.submit(threadCallable);
			System.out.println(factorial.get());
		}
	}

}
