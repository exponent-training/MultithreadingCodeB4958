package com.executorcallable;

import java.util.concurrent.Callable;

public class ThreadCallable implements Callable {

	int num;
	int fact=1;

	public ThreadCallable(int num) {
		super();
		this.num = num;
	}

	@Override
	public Object call() throws Exception {
		System.out.println("caluculating factorial started by "+Thread.currentThread().getName());
		for(int i = 1;i<=num;i++) {
			fact = fact * i;
		}
		System.out.println("caluculating factorial completed by "+Thread.currentThread().getName());
		return fact;
	}

}
