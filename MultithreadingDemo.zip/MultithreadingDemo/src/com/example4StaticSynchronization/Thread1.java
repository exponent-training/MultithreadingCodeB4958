package com.example4StaticSynchronization;

public class Thread1 extends Thread{

	
	@Override
	public void run() {
		Thread.yield();
		try {
			for(int j = 1;j<=5;j++) {
				System.out.println("Thread1: "+"--"+j);
				Thread.sleep(2000);
			}
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		Thread1 t1 = new Thread1();
		t1.start();
		t1.yield();
//		Thread.yield();
		try {
			for(int j = 1;j<=5;j++) {
				System.out.println("main: "+"--"+j);
				Thread.sleep(2000);
			}
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	
	}
}
