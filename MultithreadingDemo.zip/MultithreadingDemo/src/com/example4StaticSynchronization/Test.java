package com.example4StaticSynchronization;

public class Test {
	
	public static synchronized void print(String plname) {
		try {
			for(int j = 1;j<=3;j++) {
				System.out.println("Programming language: "+plname);
				Thread.sleep(2000);
			}
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}

}
