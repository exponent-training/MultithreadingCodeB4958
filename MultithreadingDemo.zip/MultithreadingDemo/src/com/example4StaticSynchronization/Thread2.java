package com.example4StaticSynchronization;

public class Thread2 extends Thread {
	
	Test t; // test
	String plname; //java
	
	public Thread2(Test t, String plname) {
		super();
		this.t = t;
		this.plname = plname;
	}
	
	@Override
	public void run() {
		t.print(plname);
	}

}
