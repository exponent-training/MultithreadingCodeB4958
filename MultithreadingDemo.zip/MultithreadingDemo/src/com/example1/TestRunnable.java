package com.example1;

public class TestRunnable {
	
	public static void main(String[] args) {
		DemoThread2 d2 = new DemoThread2();
		
		Thread t = new Thread(d2);
		
		t.start();
	}

}
