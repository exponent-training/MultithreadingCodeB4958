package com.example1;

public class DemoThread2 implements Runnable{

	@Override
	public void run() {
		System.out.println("DemoThread2 is running");
		
	}

}
