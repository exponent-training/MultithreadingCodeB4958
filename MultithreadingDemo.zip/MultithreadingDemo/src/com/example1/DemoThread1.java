package com.example1;

public class DemoThread1 extends Thread{

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName());
		System.out.println("DemoThread1 is running.");
	}
	
	/*
	 * public void run(int i) {
	 * System.out.println(Thread.currentThread().getName());
	 * System.out.println("DemoThread1 is running."); }
	 */
	
	
}
