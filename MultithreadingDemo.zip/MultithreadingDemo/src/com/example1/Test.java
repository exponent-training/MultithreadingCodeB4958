package com.example1;

public class Test {
	
	public static void main(String[] args) {
		DemoThread1 d = new DemoThread1();
		
		System.out.println(Thread.currentThread().getName());
		d.start();
		d.setName("DemoThread1");
//		d.run();
		
	
	}

}
