package com.java8;

public class DemoThread1 {
	
	public static void main(String[] args) {
		
		/*
		 * Runnable r = new Runnable() {
		 * 
		 * @Override public void run() { System.out.println("runnable thread running");
		 * 
		 * } };
		 * 
		 * r.run();
		 */
		
		Thread t = new Thread(()->System.out.println(Thread.currentThread().getName()));
		t.start();
	}

}
