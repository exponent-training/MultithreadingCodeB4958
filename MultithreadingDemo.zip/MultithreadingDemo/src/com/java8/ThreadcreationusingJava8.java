package com.java8;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadcreationusingJava8 {

	public static void main(String[] args) {
		
		ExecutorService service = Executors.newFixedThreadPool(2);
		
		service.submit(()->System.out.println("task initiated by: "+Thread.currentThread().getName()));
		service.submit(()->System.out.println("task initiated by: "+Thread.currentThread().getName()));
	}
}
