package com.synchblock;

public class Test {
	
	public void m1() {
		
		try {
			for(int i = 1;i<=3;i++) {
				System.out.println(Thread.currentThread().getName()+"--i= "+i);
				Thread.sleep(1500);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("-------------------------------------------------");
		synchronized (this) 	
		{
			try {
				for(int j = 1;j<=3;j++) {
					System.out.println(Thread.currentThread().getName()+"--j= "+j);
					Thread.sleep(1500);
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

}
