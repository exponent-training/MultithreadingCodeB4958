package com.synchblock;

public class Application {

	public static void main(String[] args) {
		Test test1 = new Test();
		Thread1 t1 = new Thread1(test1);

		t1.start();

		Thread1 t2 = new Thread1(test1);

		t2.start();

	}

}
