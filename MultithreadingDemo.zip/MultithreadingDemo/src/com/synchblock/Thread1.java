package com.synchblock;

public class Thread1 extends Thread {

	Test test;

	public Thread1(Test test) {
		super();
		this.test = test;
	}

	@Override
	public void run() {
		test.m1();
	}

}
