package com.example3ObjectlevelLockingSyncr;

public class Application {

	public static void main(String[] args) {

		Test test = new Test();
		Thread2 t1 = new Thread2(test, "java");

		Thread2 t2 = new Thread2(test, "python");

		t1.start();// thread-0
		t2.start();// thread-1

		//For multiple Threads the synchronization at method level not work so need to make that 
		//perticular method as static 
		/*
		 * Test test1 = new Test();
		 * 
		 * Thread2 t3 = new Thread2(test1, "HTML");
		 * 
		 * Thread2 t4 = new Thread2(test1, "CSS");
		 * 
		 * t3.start(); t4.start();
		 */
	}

}
