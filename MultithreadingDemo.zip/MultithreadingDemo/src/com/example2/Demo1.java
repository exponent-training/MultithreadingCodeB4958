package com.example2;

public class Demo1 extends Thread{
	
	@Override
	public void run() {
		
		
		//System.out.println("custom demo1 thread = "+Thread.currentThread().getPriority());
		
		for(int i = 1 ;i<=5;i++) {
			System.out.println("Demo1 is running.");
		}
	}

}
