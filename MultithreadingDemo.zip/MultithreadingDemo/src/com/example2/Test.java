package com.example2;

public class Test {
	
	public static void main(String[] args) {
		Demo1 d1 = new Demo1();
		
		d1.start();
		
		//System.out.println("main thread priority= "+Thread.currentThread().getPriority());
		
		Thread.currentThread().setPriority(6);
		
		//System.out.println("main thread priority= "+Thread.currentThread().getPriority());
		
		d1.setPriority(8);
		
		for(int i = 1 ;i<=5;i++) {
			System.out.println("main is running.");
		}
		
		//d1.setPriority(45);
		
	}

}
