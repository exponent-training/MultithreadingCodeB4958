package com.example2;

public class Thread2 extends Thread {

	@Override
	public void run() {
	System.out.println("Thread2 is running");
	}
	
	public static void main(String[] args) {
		
		Thread2 t = new Thread2();
		
		t.setDaemon(true);
		t.start();
		if (t.isDaemon()) {
			System.out.println("Thread2 is Daemon thread.");
		} else {
			System.out.println("Thread2 is not Daemon thread.");
		}
	}
}
