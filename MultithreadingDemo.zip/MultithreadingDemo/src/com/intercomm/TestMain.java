package com.intercomm;

public class TestMain {
	
	public static void main(String[] args) {
		
		FactorialThread ft = new FactorialThread();
		ft.start();
		System.out.println("factorial= "+ft.factorial);
	}

}
