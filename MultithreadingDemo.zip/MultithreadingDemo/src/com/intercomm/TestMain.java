package com.intercomm;

public class TestMain {
	
	public static void main(String[] args) {
		
		FactorialThread ft = new FactorialThread();
		ft.start();
		synchronized (ft) {
			try {
				ft.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("factorial= "+ft.factorial);
	}

}
