package com.intercomm;

public class FactorialThread extends Thread{

	
	int factorial = 1;
	
	@Override
	public void run() {
		synchronized (this) {
			for(int i = 4;i>=1;i--) {
				factorial = factorial * i;
			}
			notify();
		}
		
	}
}
