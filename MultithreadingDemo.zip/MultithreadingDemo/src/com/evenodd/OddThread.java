package com.evenodd;

public class OddThread implements Runnable{

	EvenOddDemo d;

	public OddThread(EvenOddDemo d) {
		super();
		this.d = d;
	}
	
	@Override
	public void run() {
		d.oddNum();
		
	}
}
