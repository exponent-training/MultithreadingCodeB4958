package com.evenodd;

public class HomeController {
	
	public static void main(String[] args) {
		
		EvenOddDemo demo = new EvenOddDemo(5);
		
		EventThread et = new EventThread(demo);
		
		OddThread ot = new OddThread(demo);
		
		//even thread
		Thread t1 = new Thread(et);
		
		//odd thread
		Thread t2 = new Thread(ot);
		
		t1.start();
		
		t2.start();
	}

}
