package com.evenodd;

public class EvenOddDemo {

	int startnum = 1;
	int endnum;

	public EvenOddDemo(int endnum) {
		super();
		this.endnum = endnum;
	}

	public synchronized void oddNum() {
		while (startnum <= endnum) { // 5 // 3
			if (startnum % 2 != 0) {
				System.out.println("odd no = " + startnum); // 1 3
				startnum++; // 2
				notify();
			} else {
				try {
					wait(); // pause
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public synchronized void evenNum() {
		while (startnum <= endnum) { // 2
			if (startnum % 2 == 0) {
				System.out.println("even no = " + startnum); // 2
				startnum++; // 3
				notify();
			} else {
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
