package com.evenodd;

public class EventThread implements Runnable {

	EvenOddDemo d;

	public EventThread(EvenOddDemo d) {
		super();
		this.d = d;
	}

	@Override
	public void run() {
		d.evenNum();

	}

}
